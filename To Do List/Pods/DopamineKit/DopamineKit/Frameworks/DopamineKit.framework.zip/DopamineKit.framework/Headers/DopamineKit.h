//
//  DopamineKit.h
//  DopamineKit
//
//  Created by Akash Desai on 6/3/16.
//  Copyright © 2016 DopamineLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DopamineKit.
FOUNDATION_EXPORT double DopamineKitVersionNumber;

//! Project version string for DopamineKit.
FOUNDATION_EXPORT const unsigned char DopamineKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DopamineKit/PublicHeader.h>


